async function saveWorkspace(name, tabs) {

    const workspace = tabs.map(tab => ({
        title: tab.title,
        url: tab.url
    }));

    await chrome.storage.local.set({
        [name]: workspace
    });

}

async function getWorkspace(name) {

    const data = await chrome.storage.local.get(name);

    return data[name];

}