const promptInput = document.getElementById("prompt");
const executeButton = document.getElementById("executeBtn");
const statusText = document.getElementById("status");

executeButton.addEventListener("click", async () => {

    const userCommand = promptInput.value;

    if (userCommand.trim() === "") {

        statusText.textContent = "❌ Please enter a command.";
        return;

    }
    
    const command = parseCommand(userCommand);

switch (command.action) {

    case "save":

        const tabs = await getCurrentTabs();

        await saveWorkspace(command.workspace, tabs);

        statusText.textContent =
            `✅ Workspace "${command.workspace}" saved!`;

        break;

    case "open":

        const workspace = await getWorkspace(command.workspace);

        if (!workspace) {

            statusText.textContent =
                "❌ Workspace not found.";

            return;
        }

        await openWorkspaceTabs(workspace);

        statusText.textContent =
            `🚀 Workspace "${command.workspace}" opened!`;

        break;

    default:

        statusText.textContent =
            "❌ Unknown command.";

}
console.log(command);

    const tabs = await getCurrentTabs();

    await saveWorkspace("Study", tabs);

console.log("Workspace Saved!");

statusText.textContent = "✅ Workspace 'Study' saved!";

});