function parseCommand(command) {

    command = command.trim().toLowerCase();

    if (command.startsWith("open")) {

    const workspace = command.replace("open", "").trim();

    return {
        action: "open",
        workspace
    };

}

if (command.startsWith("save")) {

    const parts = command.split(" as ");

    if (parts.length < 2) {
        return {
            action: "unknown"
        };
    }

    return {
        action: "save",
        workspace: parts[1].trim()
    };

}
return {
    action: "unknown"
};
}